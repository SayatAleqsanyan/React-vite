const Error = ({ message }) => {
  return <div>Error: {message}</div>;
};

export default Error;